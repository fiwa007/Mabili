import csv
import xml.etree.ElementTree as ET

# Read data from CSV file
csv_file = '/Users/refilwemaleka/Desktop/Mabili/Data Science/Assignments/Module 2 Assignment/Ass2csv.csv'

# Define XML structure
root = ET.Element('data')
rows = ET.SubElement(root, 'rows')

# Parse CSV data and add it to XML
with open(csv_file, newline='') as f:
    reader = csv.DictReader(f)
    for row in reader:
        xml_row = ET.SubElement(rows, 'row')
        for key, value in row.items():
            ET.SubElement(xml_row, key).text = value

# Write XML data to output.xml
tree = ET.ElementTree(root)
tree.write('output.xml')

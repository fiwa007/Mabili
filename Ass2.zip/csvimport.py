import csv
import xml.dom.minidom

# Function to convert CSV to XML
def csv_to_xml(csv_file, xml_file):
    # Create XML document
    doc = xml.dom.minidom.Document()
    data_element = doc.createElement("data")
    doc.appendChild(data_element)

    # Read CSV file and convert to XML
    with open(csv_file, 'r') as file:
        csv_reader = csv.DictReader(file)
        for i, row in enumerate(csv_reader, 1):
            print(f"Processing row {i}: {row}")  # Debug print
            entry_element = doc.createElement("entry")
            data_element.appendChild(entry_element)
            for key, value in row.items():
                field_element = doc.createElement(key)
                field_value = str(value) if value is not None else ''  # Convert None to empty string
                field_element.appendChild(doc.createTextNode(field_value))
                entry_element.appendChild(field_element)

    # Write XML document to file
    with open(xml_file, 'w') as xmlfile:
        xmlfile.write(doc.toprettyxml())

    print("Conversion completed.")

# Main function
def main():
    csv_file = "/Users/refilwemaleka/Desktop/Mabili/Data Science/Assignments/Module 2 Assignment/Ass2csv.csv"
    xml_file = "/Users/refilwemaleka/Desktop/Mabili/Data Science/Assignments/Module 2 Assignment/output.xml"
    csv_to_xml(csv_file, xml_file)

if __name__ == "__main__":
    main()

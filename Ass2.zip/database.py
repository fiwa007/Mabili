import sqlite3
import pandas as pd
import requests
from bs4 import BeautifulSoup
from tabulate import tabulate

# Function to parse the HTML content of a webpage
def parse_html(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    return soup

# Function to extract table data from the parsed HTML
def extract_table_data(soup):
    table = soup.find("table")
    if table:
        table_data = []
        for row in table.find_all('tr'):
            row_data = [cell.get_text(strip=True) for cell in row.find_all(['th', 'td'])]
            table_data.append(row_data)
        return table_data
    else:
        return None

# Read CSV file into DataFrame
csv_data_df = pd.read_csv('/Users/refilwemaleka/Desktop/Mabili/Data Science/Assignments/Module 2 Assignment/Ass2csv.csv')

# Filter CSV data based on condition (Data_value > 80000)
filtered_csv_data_df = csv_data_df[csv_data_df['Data_value'] > 80000]

# Display DataFrame
print("CSV Data with Data_value > 80000:")
print(tabulate(filtered_csv_data_df, headers='keys', tablefmt='psql'))

# Saving filtered CSV data to output.txt
with open("output.txt", "w") as file:
    # Write heading for CSV data
    file.write("CSV Data with Data_value > 80000:\n")
    # Convert DataFrame to tabular format and write to file
    file.write(tabulate(filtered_csv_data_df, headers='keys', tablefmt='psql') + "\n\n")

# URL of the webpage containing the table
url = "https://www.w3schools.com/html/html_tables.asp"

# Parsing the HTML content of the webpage
soup = parse_html(url)

# Extracting table data from parsed HTML
html_table_data = extract_table_data(soup)

# Displaying HTML table data
if html_table_data:
    print("\nHTML Table Data:")
    # Print HTML table data with tabulate
    print(tabulate(html_table_data, headers=html_table_data[0], tablefmt='psql'))
else:
    print("HTML Table not found.")

# Saving HTML table data to output.txt
with open("output.txt", "a") as file:
    # Write heading for HTML data
    file.write("\nHTML Table Data:\n")
    if html_table_data:
        # Convert HTML table data to tabular format and write to file
        file.write(tabulate(html_table_data, headers=html_table_data[0], tablefmt='psql'))

# EXTRACTING THE LAST 3 ROWS FROM THE JSON & FIRST 3 ROWS FROM THE HTML FILES
import pandas as pd
from tabulate import tabulate
import json
import xml.etree.ElementTree as ET

# Read CSV file
csv_data = pd.read_csv('/Users/refilwemaleka/Desktop/Mabili/Data Science/Assignments/Module 2 Assignment/Ass2csv.csv')
csv_data_filtered = csv_data[csv_data['Data_value'] > 80000]

# Read JSON file
with open('output.json', 'r') as json_file:
    json_data = json.load(json_file)[:3]  # Only first 3 rows

# Read XML file
tree = ET.parse('output.xml')
root = tree.getroot()
xml_data = []

# Extract last 3 rows from XML data
for row in root.findall('.//row')[-3:]:
    xml_row = [elem.text for elem in row]
    xml_data.append(xml_row)

# Define HTML table data (replace with your actual HTML table data)
html_data = [
    {"Company": "Company A", "Contact": "John Doe", "Country": "USA"},
    {"Company": "Company B", "Contact": "Jane Smith", "Country": "Canada"},
    {"Company": "Company C", "Contact": "Bob Johnson", "Country": "UK"}
]

# Write to output.txt
with open('output.txt', 'w') as output_file:
    output_file.write("CSV Data with Data_value > 80000:\n")
    output_file.write(tabulate(csv_data_filtered, headers='keys', showindex=True, tablefmt='github'))
    output_file.write("\n\n")

    # Add HTML Table Data
    output_file.write("HTML Table Data:\n")
    output_file.write(tabulate(html_data, headers='keys', showindex=False, tablefmt='github'))
    output_file.write("\n\n")

    # Add JSON Table Data
    output_file.write("JSON Table Data:\n")
    json_headers = ["Index"] + list(json_data[0].keys())
    json_table = [[i] + list(row.values()) for i, row in enumerate(json_data, 1)]
    output_file.write(tabulate(json_table, headers=json_headers, tablefmt='github'))
    output_file.write("\n\n")

    # Add XML Table Data
    output_file.write("XML Table Data:\n")
    xml_headers = ["Element"] + [child.tag for child in root[0]]
    xml_table = [xml_headers]
    xml_table.extend(xml_data)
    output_file.write(tabulate(xml_table, headers='firstrow', tablefmt='github'))
    output_file.write("\n\n")

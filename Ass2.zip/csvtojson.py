import csv
import json

# Function to convert CSV to JSON
def csv_to_json(csv_file, json_file):
    # Read CSV file and convert to JSON
    data = []
    with open(csv_file, 'r') as file:
        csv_reader = csv.DictReader(file)
        for row in csv_reader:
            data.append(row)

    # Write JSON data to file
    with open(json_file, 'w', newline='\n') as jsonfile:  # Specify newline='\n'
        jsonfile.write("[\n")
        for i, record in enumerate(data):
            json.dump(record, jsonfile, indent=4)
            if i < len(data) - 1:
                jsonfile.write(",\n")
        jsonfile.write("\n]")

    print("Conversion completed.")

# Main function
def main():
    csv_file = "/Users/refilwemaleka/Desktop/Mabili/Data Science/Assignments/Module 2 Assignment/Ass2csv.csv"
    json_file = "/Users/refilwemaleka/Desktop/Mabili/Data Science/Assignments/Module 2 Assignment/output.json"
    csv_to_json(csv_file, json_file)

if __name__ == "__main__":
    main()
